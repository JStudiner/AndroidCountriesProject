package com.example.countriesv2

data class Country(val countryName: String?)